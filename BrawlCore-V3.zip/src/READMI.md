BrawlCore-V3 AND alteration of Java-Brawl to true code.
good luck!
