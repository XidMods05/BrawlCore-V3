import BrawlCore_Laser.BrawlCore_Titan.Modules.ModuleLoader;
import BrawlCore_Manager.ConfigLogger;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello developer");
        ConfigLogger configLogger = new ConfigLogger();
        configLogger.loadConfs();
        ModuleLoader moduleLoader = new ModuleLoader();
        moduleLoader.load();
    }

}