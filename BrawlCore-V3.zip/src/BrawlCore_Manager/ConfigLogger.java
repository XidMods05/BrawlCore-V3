package BrawlCore_Manager;

import BrawlCore_Laser.BrawlCore_Titan.Console.ConsolePrinter;

public class ConfigLogger {
    Config config = new Config();
    ConsolePrinter consolePrinter = new ConsolePrinter();

    public void loadConfs() {
        if (config.isDevEnv) {
            consolePrinter.conf("IsDev included!");
        }
    }
}
