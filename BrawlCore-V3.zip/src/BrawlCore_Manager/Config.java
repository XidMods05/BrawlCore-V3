package BrawlCore_Manager;

public class Config {
    public boolean isDevEnv = true;
}
