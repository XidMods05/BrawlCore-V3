package BrawlCore_Laser.BrawlCore_Servers.LobbyServer.Converter;

import BrawlCore_Laser.BrawlCore_General.DataStream.ByteStream;

public class PiranhaMessage {
    public ByteStream byter = new ByteStream();

    public void getEncodingLength() {
    }

    public void getMessageVersion() {
    }

    public void getByteStream() {
    }

    public void setMessageVersion() {
    }
}
