package BrawlCore_Laser.BrawlCore_Servers.LobbyServer.Converter.Packets.Server.Home;

import BrawlCore_Laser.BrawlCore_General.Network.PoolMessages.Handler;
import BrawlCore_Laser.BrawlCore_Servers.LobbyServer.Converter.PiranhaMessage;

import java.io.DataOutputStream;

public class OwnHomeDataMessage {
    DataOutputStream WriteDater;
    PiranhaMessage message = new PiranhaMessage();

    public OwnHomeDataMessage(DataOutputStream WriteData) {
        this.WriteDater = WriteData;
    }

    public int getMessageType() {
        return 24101;
    }

    public int getMessageVersion() {
        return 0;
    }

    public OwnHomeDataMessage encode() {
        // ohd code.
        new Handler(getMessageType(), getMessageVersion(), message.byter.getBytes()).send(this.WriteDater);
        return this;
    }

    public void actions() {
    }
}
