package BrawlCore_Laser.BrawlCore_Servers.LobbyServer.Converter.Packets.Server;

import BrawlCore_Laser.BrawlCore_General.Network.PoolMessages.Handler;
import BrawlCore_Laser.BrawlCore_Servers.LobbyServer.Converter.PiranhaMessage;

import java.io.DataOutputStream;

public class ServerHelloMessage {
    DataOutputStream WriteDater;
    PiranhaMessage message = new PiranhaMessage();

    public ServerHelloMessage(DataOutputStream WriteData) {
        this.WriteDater = WriteData;
    }

    public int getMessageType() {
        return 20100;
    }

    public int getMessageVersion() {
        return 0;
    }

    public ServerHelloMessage encode() {
        message.byter.writeInt(24); // SSl
        for (var index = 0; index < 24; index++) {
            message.byter.writeByte(0xFF); // 0
        }
        new Handler(getMessageType(), getMessageVersion(), message.byter.getBytes()).send(this.WriteDater);
        return this;
    }

    public void actions() {
    }
}
