package BrawlCore_Laser.BrawlCore_Servers.LobbyServer.Converter.Packets.Client.Login;

import BrawlCore_Laser.BrawlCore_Servers.LobbyServer.Converter.Packets.Server.Home.OwnHomeDataMessage;

import java.io.DataOutputStream;

public class LoginMessage {
    DataOutputStream writeData;
    private int a1, a2, a3, a4, a5;

    public LoginMessage(byte[] MessagePayload, DataOutputStream writeData) {
        this.writeData = writeData;
    }

    public void goLobbyEnvironment() {
        new OwnHomeDataMessage(this.writeData)
                .encode()
                .actions();
    }
}
