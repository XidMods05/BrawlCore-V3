package BrawlCore_Laser.BrawlCore_Servers.LobbyServer.Converter.Packets.Client;

import BrawlCore_Laser.BrawlCore_Servers.LobbyServer.Converter.Packets.Server.ServerHelloMessage;
import BrawlCore_Laser.BrawlCore_Servers.LobbyServer.Converter.PiranhaMessage;

import java.io.DataOutputStream;

public class ClientHelloMessage {
    DataOutputStream writeData;
    PiranhaMessage message = new PiranhaMessage();
    private int a1, a2, a3, a4, a5;

    public ClientHelloMessage(byte[] MessagePayload, DataOutputStream writeData) {
        this.writeData = writeData;
    }

    public ClientHelloMessage decode() {
        this.a1 = message.byter.readInt();
        this.a2 = message.byter.readInt();
        this.a3 = message.byter.readInt();
        this.a4 = message.byter.readInt();
        this.a5 = message.byter.readInt();
        return this;
    }

    public void process() {
        new ServerHelloMessage(this.writeData)
                .encode()
                .actions();
    }
}
