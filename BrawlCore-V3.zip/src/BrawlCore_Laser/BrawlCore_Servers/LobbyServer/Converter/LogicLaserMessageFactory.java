package BrawlCore_Laser.BrawlCore_Servers.LobbyServer.Converter;

import BrawlCore_Laser.BrawlCore_Servers.LobbyServer.Converter.Packets.Client.ClientHelloMessage;

import java.io.DataOutputStream;

public class LogicLaserMessageFactory {
    public void Processor(int GetMessageType, byte[] MessagePayload, DataOutputStream writeData) { // Create message by type. AKA: Processor
        switch (GetMessageType) {
            case 10100:
                new ClientHelloMessage(MessagePayload, writeData)
                        .decode()
                        .process();
                break;
        }
    }
}
