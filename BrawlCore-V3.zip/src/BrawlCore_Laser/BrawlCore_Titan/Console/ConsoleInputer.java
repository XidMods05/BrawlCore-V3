package BrawlCore_Laser.BrawlCore_Titan.Console;

import java.util.Scanner;

public class ConsoleInputer {
    Scanner scanner = new Scanner(System.in);

    private String InputLine() {
        return scanner.nextLine();
    }

    private int InputNumber() {
        return scanner.nextInt();
    }

    private boolean InputAnswer() {
        String answer = scanner.nextLine();
        boolean bool = switch (answer) {
            case "Yes", "Y", "yes", "y", "Ye", "ye", "True", "T", "true", "t" -> true;
            case "No", "no", "Not", "not", "N", "n", "False", "F", "false", "f" -> false;
            default -> false;
        };
        boolean trfo = bool;
        return trfo;
    }

    public String inputLine() {
        return InputLine();
    }

    public int inputNum() {
        return InputNumber();
    }

    public boolean inputAnswer() {
        return InputAnswer();
    }
}
