package BrawlCore_Laser.BrawlCore_Titan.Console;

public class ConsoleHandler {
    ConsoleInputer consoleInputer = new ConsoleInputer();

    private void handleCommands() {
        while (true) {
            String command = consoleInputer.inputLine();
            if (command == null) continue;
            if (!command.startsWith("/")) continue;
            String cmd = command.substring(1);
            String[] args = cmd.split(" ");
            if (args.length < 1) continue;
            switch (args[0]) {
                // TODO: write your commands XD, and delete my comms. Ok. Yes, I stole the code from xeondev. XDDDDDD \\
                case "xid":
                    consoleInputer.inputAnswer();
                case "dead":
                    consoleInputer.inputAnswer();
                case "da.":
                    consoleInputer.inputAnswer();
            }
        }
    }
}
