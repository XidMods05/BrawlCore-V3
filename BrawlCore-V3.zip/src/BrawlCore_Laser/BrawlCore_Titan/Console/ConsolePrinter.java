package BrawlCore_Laser.BrawlCore_Titan.Console;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

public class ConsolePrinter {
    private <logging> void print(String text) {
        System.out.println(text);
        log(text);
    }

    protected void log(String text) {
        try {
            PrintWriter pw = new PrintWriter(new FileOutputStream("src/Logging.log", true));
            text = text + "  @log";
            pw.println(text);
            pw.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void start(String text) {
        print("[START] " + text);
    }

    public void stop(String text) {
        print("[STOP] " + text);
    }

    public void lobby(String text) {
        print("[LOBBY] " + text);
    }

    public void battle(String text) {
        print("[BATTLE] " + text);
    }

    public void write(String text) {
        print("[WRITE] " + text);
    }

    public void read(String text) {
        print("[READ] " + text);
    }

    public void encode(String text) {
        print("[ENCODE] " + text);
    }

    public void decode(String text) {
        print("[DECODE] " + text);
    }

    public void actions(String text) {
        print("[ACTIONS] " + text);
    }

    public void process(String text) {
        print("[PROCESS] " + text);
    }

    public void send(String text) {
        print("[SEND] " + text);
    }

    public void receive(String text) {
        print("[RECEIVE] " + text);
    }

    public void tcp(String text) {
        print("[TCP] " + text);
    }

    public void udp(String text) {
        print("[UDP] " + text);
    }

    public void http(String text) {
        print("[HTTP] " + text);
    }

    public void debug(String text) {
        print("[DEBUG] " + text);
    }

    public void info(String text) {
        print("[INFO] " + text);
    }

    public void echo(String text) {
        print("[*] " + text);
    }

    public void pool(String text) {
        print("[@] " + text);
    }

    public void vole(String text) {
        print("[!] " + text);
    }

    public void load(String text) {
        print("[l+] " + text);
    }

    public void conf(String text) {
        print("[CONFIG] " + text);
    }

    public void warn(String text) {
        print("[WARNING] " + text);
    }

    public void error(String text) {
        print("[ERROR] " + text);
    }

    public void gen(String text) {
        print("[GENERAL] " + text);
    }

    public void global(String text) {
        print("[GLOBAL] " + text);
    }

    public void local(String text) {
        print("[LOCAL] " + text);
    }

    public void analyse(String text) {
        print("[ANALYSE] " + text);
    }

    public void protect(String text) {
        print("[PROTECT] " + text);
    }
}
