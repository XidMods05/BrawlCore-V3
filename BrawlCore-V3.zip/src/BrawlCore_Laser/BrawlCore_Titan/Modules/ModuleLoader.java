package BrawlCore_Laser.BrawlCore_Titan.Modules;

import BrawlCore_Laser.BrawlCore_General.Network.TCP.TCP;
import BrawlCore_Laser.BrawlCore_Titan.Console.ConsolePrinter;

public class ModuleLoader {
    TCP tcp = new TCP();
    ConsolePrinter consolePrinter = new ConsolePrinter();

    public void load() {
        loadNetwork();
    }

    private void loadNetwork() {
        new Thread(() -> {
            tcp.cleaner();
        }).start();
        new Thread(() -> {
            tcp.bind();
        }).start();
        consolePrinter.load("Network loaded!");
    }
}
