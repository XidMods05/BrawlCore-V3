package BrawlCore_Laser.BrawlCore_General.GlobalOptions.ClientSync;

import BrawlCore_Laser.BrawlCore_General.Network.PoolMessages.Handler;
import BrawlCore_Laser.BrawlCore_Servers.LobbyServer.Converter.PiranhaMessage;

import java.io.DataOutputStream;

public class LoginOkMessage {
    DataOutputStream WriteDater;
    PiranhaMessage message = new PiranhaMessage();

    public LoginOkMessage(DataOutputStream WriteData) {
        this.WriteDater = WriteData;
    }

    public int getMessageType() {
        return 20104;
    }

    public int getMessageVersion() {
        return 1;
    }

    public void encode() {
        message.byter.writeLong(0, 1); // homeID, SCid
        message.byter.writeLong(0, 1); // homeID, SCid
        message.byter.writeString("llllllll"); // SCidToken
        message.byter.writeString("3333"); // XD
        message.byter.writeString("3333"); // XD x2 (I just lazy) ^^^^^^^^^^~~~~~~~~ next "fields" write yourself.
        new Handler(getMessageType(), getMessageVersion(), message.byter.getBytes()).send(this.WriteDater);
    }
}
