package BrawlCore_Laser.BrawlCore_General.GlobalOptions;

import BrawlCore_Laser.BrawlCore_General.GlobalOptions.ClientSync.LoginOkMessage;
import BrawlCore_Laser.BrawlCore_Servers.LobbyServer.Converter.Packets.Client.Login.LoginMessage;
import BrawlCore_Laser.BrawlCore_Servers.LobbyServer.Converter.PiranhaMessage;
import BrawlCore_Laser.BrawlCore_Titan.Console.ConsolePrinter;

import java.io.DataOutputStream;

public class TitanLoginMessage {
    DataOutputStream writeData;
    ConsolePrinter consolePrinter = new ConsolePrinter();
    byte[] MessagePayload;
    PiranhaMessage message = new PiranhaMessage();
    String IP;
    private int a1, a2;
    private String a3;

    public TitanLoginMessage(byte[] MessagePayload, DataOutputStream writeData, String IP) {
        this.MessagePayload = MessagePayload;
        this.writeData = writeData;
        this.IP = IP;
    }

    public TitanLoginMessage readClientData() {  // LoginMessage::decode
        this.a1 = message.byter.readInt();// ) -      homeID
        //                                   ) - ByteStream::readLong
        this.a2 = message.byter.readInt();// ) -      SCid
        this.a3 = message.byter.readString(); // SCidToken
        // Там дальше всякие LoginMessage::decodeMessageVersion идут, мне лень их писать.
        return this; // // да сам ты lv1_checksum_crypto_checksum_key1, я заебался эту хуйню глядеть, дохуя сабов прочекал (PS: Нашел с ~8 попытки.). Ну нахуя блядь я выбрал эту версию.
    }

    public TitanLoginMessage auth() {
        new LoginOkMessage(this.writeData).encode();
        new LoginMessage(MessagePayload, writeData).goLobbyEnvironment(); // Environment

        return this;
    }

    public void printerData() {
        //consolePrinter.debug("Client data for IP: " + IP + ". " + "Data: a1 = " + this.a1 + " a2 = " + this.a2 + " a3 = " + this.a3 + ".");
    }
}
