package BrawlCore_Laser.BrawlCore_General.Network.TCP.IP;

import BrawlCore_Laser.BrawlCore_General.GlobalOptions.TitanLoginMessage;
import BrawlCore_Laser.BrawlCore_Servers.LobbyServer.Converter.LogicLaserMessageFactory;
import BrawlCore_Laser.BrawlCore_Titan.Console.ConsolePrinter;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;

public class SocketMode extends Thread { // AKA: Messaging
    public ConsolePrinter consolePrinter = new ConsolePrinter();
    public Socket client;
    public DataInputStream readData;
    public DataOutputStream writeData;
    public int poolData;
    public LogicLaserMessageFactory LaserMessage;

    public SocketMode(Socket socket) {
        this.client = socket;
        this.LaserMessage = new LogicLaserMessageFactory();
        try {
            this.readData = new DataInputStream(this.client.getInputStream());
            this.writeData = new DataOutputStream(this.client.getOutputStream());
            this.poolData = 0;
        } catch (IOException ignored) {
        }
    }

    public void run() {
        String IP = ((InetSocketAddress) client.getRemoteSocketAddress()).getAddress().toString().substring(1);

        byte[] TCPheader, MessagePayload;
        short GetMessageType;
        int GetMessageLength;
        while (true) {
            TCPheader = new byte[7];
            try {
                this.poolData = this.readData.read(TCPheader);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            GetMessageType = (short) (((TCPheader[0] & 0xFF) << 8) | (TCPheader[1] & 0xFF)); // asio::detail::resolver_service<asio::ip::tcp>::~resolver_service
            GetMessageLength = (((TCPheader[2] & 0xFF) << 16) | ((TCPheader[3] & 0xFF) << 8) | (TCPheader[4] & 0xFF));
            MessagePayload = new byte[GetMessageLength];
            try {
                this.poolData = this.readData.read(MessagePayload);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            if (GetMessageType == 0) {
                break;
            } else if (GetMessageType == 110) {
                break;
            } else if (GetMessageType == 300) {
                break;
            }
            if (GetMessageType == 10101) {
                new TitanLoginMessage(MessagePayload, writeData, IP)
                        .readClientData()
                        .auth()
                        .printerData();
            } else {
                consolePrinter.tcp("Received message with ID: " + GetMessageType + ".");
                this.LaserMessage.Processor(GetMessageType, MessagePayload, this.writeData);
            }
        }
        try {
            this.readData.close();
            this.writeData.close();
            this.client.close();
        } catch (IOException ignored) {
        }
        consolePrinter.tcp(IP + " disconnected!");
    }
}
