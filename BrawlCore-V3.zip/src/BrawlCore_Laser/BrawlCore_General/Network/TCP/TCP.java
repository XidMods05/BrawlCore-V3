package BrawlCore_Laser.BrawlCore_General.Network.TCP;

import BrawlCore_Laser.BrawlCore_General.Network.TCP.IP.SocketMode;
import BrawlCore_Laser.BrawlCore_Titan.Console.ConsolePrinter;
import BrawlCore_Manager.Config;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

public class TCP {
    ConsolePrinter consolePrinter = new ConsolePrinter();
    Config config = new Config();
    Integer socketLVL = 3;
    int port = socketLVL * 3113;

    HashMap<String, Integer> persIP = new HashMap<>();

    public void cleaner() {
        while (true) {
            try {
                TimeUnit.MILLISECONDS.sleep(3500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            if (!config.isDevEnv) {
                persIP.clear();
            }
        }
    }

    public void bind() {
        try (ServerSocket server = new ServerSocket(port)) {
            consolePrinter.start("TCP server started! LVL: " + socketLVL + " Port: " + port + ".");
            while (server.isBound()) {
                Socket client = server.accept(); // asio::ip::basic_resolver_results<asio::ip::tcp>::create
                String IP = ((InetSocketAddress) client.getRemoteSocketAddress()).getAddress().toString().substring(1);
                consolePrinter.tcp("New connection! LVL: " + socketLVL + " " + "IP: " + IP + "!");
                new SocketMode(client).start(); // asio::ip::tcp,Messaging::connect
                if (!config.isDevEnv) {
                    if (!persIP.containsKey(IP)) {
                        persIP.put(IP, 0);
                        // IP put
                    } else {
                        Integer count = persIP.get(IP);
                        Integer value = count + 1;
                        persIP.put(IP, value);
                        if (persIP.get(IP) >= 2) {
                            Runtime.getRuntime().exec("iptables or windows defender  command......");
                            // BAN IP IN YOUR OS.
                            client.close();
                        }
                    }
                }
            }
        } catch (IOException ignored) {
        }
    }
}
