package BrawlCore_Laser.BrawlCore_General.Network.PoolMessages;

import BrawlCore_Laser.BrawlCore_Titan.Console.ConsolePrinter;

import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;

public class Handler { // Ohhhh yes S.B shit code))))
    private final ConsolePrinter consolePrinter = new ConsolePrinter();
    private final int GetMessageType;
    private final int GetMessageVersion;
    private final byte[] MessagePayload;
    private final byte[] TCPheader;

    public Handler(int a1, int a2, byte[] a3) {
        this.GetMessageType = a1;
        this.GetMessageVersion = a2;
        this.MessagePayload = a3;
        this.TCPheader = new byte[7];
    }

    public byte[] pool(byte[] a1, byte[] a2) {

        ByteBuffer buffer = ByteBuffer.wrap(new byte[a1.length + a2.length]);
        buffer.put(a1);
        buffer.put(a2);
        return buffer.array();
    }

    public void setHeader() {
        int len = this.MessagePayload.length;
        this.TCPheader[0] = (byte) (GetMessageType >> 8 & 0xFF);
        this.TCPheader[1] = (byte) (GetMessageType & 0xFF);
        this.TCPheader[2] = (byte) (len >> 16 & 0xFF);
        this.TCPheader[3] = (byte) (len >> 8 & 0xFF);
        this.TCPheader[4] = (byte) (len & 0xFF);
        this.TCPheader[5] = (byte) (GetMessageVersion >> 8 & 0xFF);
        this.TCPheader[6] = (byte) (GetMessageVersion & 0xFF);
    }

    public void send(DataOutputStream writeData) {
        this.setHeader();
        byte[] packetPure = this.pool(this.TCPheader, this.MessagePayload);
        try {
            writeData.write(packetPure);
            consolePrinter.tcp("Message of ID: " + GetMessageType + " was sent.");
        } catch (IOException ignored) {
        }
    }
}
