package BrawlCore_Laser.BrawlCore_General.DataStream;

import java.util.Arrays;

public class ByteStream {
    public int PoolOffset = 0;
    public byte[] MessagePayload;

    public ByteStream() {
        this.MessagePayload = new byte[25000];
    }

    public ByteStream(byte[] bytes) {
        this.MessagePayload = bytes;
    }

    public int readOffset() {
        int result = (this.MessagePayload[PoolOffset] & 0xFF);
        PoolOffset += 1;
        return result;
    }

    public void writeOffset(int a1) {
        byte v1 = (byte) a1;
        this.MessagePayload[PoolOffset] = v1;
        PoolOffset += 1;
    }


    public byte readByte() {
        return (byte) this.readOffset();
    }

    public byte[] readBytes(int size) {
        byte[] result = new byte[size];
        for (var index = 0; index < size; index++) {
            result[index] = this.readByte();
        }
        return result;
    }

    public int readInt() {
        return (this.readOffset() << 24 | this.readOffset() << 16 | this.readOffset() << 8 | this.readOffset());
    }

    public int readVInt() {
        int b = this.readByte();
        int sign = b >> 6, ret = b & 0x3F, off = 3;
        while ((b & 0x80) != 0) {
            b = this.readByte();
            ret |= b & 0x7F;
            off += 7;
        }
        if (sign == 0) {
            return ret;
        } else {
            return ret | (-1 << off);
        }
    }

    public Boolean readBoolean() {
        return this.readOffset() >= 1;
    }

    public String readString() {
        String result = "";
        int len = this.readInt();
        if (len <= 0) {
            return "";
        }
        result = new String(this.readBytes(len));
        return result;
    }


    public void writeByte(int a1) {
        this.writeOffset(a1);
    }

    public void writeUInt(int a1) {
        this.writeOffset(a1 & 0xFF);
    }

    public void writeBoolean(Boolean a1) {
        this.writeOffset(a1 ? 1 : 0);
    }

    public void writeInt(int a1) {
        this.writeOffset((a1 >> 24) & 0xFF);
        this.writeOffset((a1 >> 16) & 0xFF);
        this.writeOffset((a1 >> 8) & 0xFF);
        this.writeOffset(a1 & 0xFF);
    }

    public void writeIntCount(int count, int value) {
        for (int i = 0; i <= count; i++) {
            writeInt(value);
        }
    }

    public void writeVInt(int a1) {  // shit moment, because it just reborn Java-Brawl.
        int v1, v2, v3;
        v1 = (((a1 >> 25) & 0x40) | (a1 & 0x3F));
        v2 = ((a1 ^ (a1 >> 31)) >> 6);
        a1 >>= 6;
        if (v2 == 0) {
            this.writeByte(v1);
        } else {
            this.writeByte(v1 | 0x80);
            v2 >>= 7;
            v3 = 0;
            if (v2 > 0) {
                v3 = 0x80;
            }
            this.writeByte((a1 & 0x7F) | v3);
            a1 >>= 7;
            while (v2 != 0) {
                v2 >>= 7;
                v3 = 0;
                if (v2 > 0) {
                    v3 = 0x80;
                }
                this.writeByte((a1 & 0x7F) | v3);
                a1 >>= 7;
            }
        }
    }

    public void writeVCount(int a1) {
        writeVInt(a1);
        for (int i = 0; i <= a1; i++) {
            writeVInt(i);
        }
    }

    public void writeVIntCount(int count, int value) {
        for (int i = 0; i <= count; i++) {
            writeVInt(value);
        }
    }

    public void writeArrayVInt(int[] a1) {
        writeVInt(a1.length);
        for (int i : a1) {
            writeVInt(i);
        }
    }

    public void writeLong(int a1, int a2) {
        writeInt(a1);
        writeInt(a2);
    }

    public void writeVLong(int a1, int a2) {
        writeVInt(a1);
        writeVInt(a2);
    }

    public void writeString() {
        this.writeInt(-1);
    }

    public void writeString(String a1) {
        this.writeInt(a1.length());
        int strOffset = 0;
        for (int index = 0; index < a1.getBytes().length; index++) {
            this.writeOffset(a1.getBytes()[strOffset]);
            strOffset += 1;
        }
    }

    public void writeDataReference(int a1) {
        this.writeVInt(a1);
    }

    public void writeDCount(int count, int Gid, int valueData) {
        writeVInt(count);
        for (int i = 0; i <= count; i++) {
            writeDataReference(Gid, valueData);
        }
    }

    public void writeDataReference(int a1, int a2) {
        this.writeVInt(a1);
        this.writeVInt(a2);
    }

    public byte[] getBytes() {
        return Arrays.copyOfRange(this.MessagePayload, 0, this.PoolOffset);
    }
}
