package BrawlCore_Laser.BrawlCore_General.DataStream;

public class BitStream {
    // no code
}
